package com.example.slider2

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class compras : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_compras)

        val bt_casa_compras = findViewById<ImageView>(R.id.bt_casa_compras)
        bt_casa_compras.setOnClickListener {
            val intent = Intent(this, inicio::class.java)
            startActivity(intent)
            finish()
        }
        val bt_compras_compras = findViewById<ImageView>(R.id.bt_compras_compras)
        bt_compras_compras.setOnClickListener {
            val intent = Intent(this, compras ::class.java)
            startActivity(intent)
            finish()
        }
        val bt_usuario_compras = findViewById<ImageView>(R.id.bt_usuario_compras)
        bt_usuario_compras.setOnClickListener {
            val intent = Intent(this, perfil ::class.java)
            startActivity(intent)
            finish()
        }


            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
            }
        }
    }