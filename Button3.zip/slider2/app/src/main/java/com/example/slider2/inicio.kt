package com.example.slider2

import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2

class inicio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.inicio)

        val bt_casa = findViewById<ImageView>(R.id.bt_casa)
        bt_casa.setOnClickListener{
            val intent = Intent(this, inicio :: class.java)
            startActivity(intent)
            finish()
        }


        val bt_compras = findViewById<ImageView>(R.id.bt_compras)
        bt_compras.setOnClickListener{
            val intent = Intent(this, compras :: class.java)
            startActivity(intent)
            finish()
        }
        val bt_usuario = findViewById<ImageView>(R.id.bt_usuario)
        bt_usuario.setOnClickListener{
            val intent = Intent(this, perfil :: class.java)
            startActivity(intent)
            finish()
        }



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val sliderViewPager = findViewById<ViewPager2>(R.id.sliderViewPager)
        val sliderViewPager2 = findViewById<ViewPager2>(R.id.sliderViewPager2)
        val images = listOf(
            R.drawable.ropa,
            R.drawable.computadora,
            R.drawable.limpieza
        )
        val images2 = listOf(
            R.drawable.manta,
            R.drawable.lenovo,
            R.drawable.limpiezas
        )


        // Adaptador del Slider
        sliderViewPager.adapter = SliderAdapter(images)
        sliderViewPager2.adapter = SliderAdapter(images2)

        // Agregar Espaciado
        val marginPx = resources.getDimensionPixelSize(R.dimen.slider_margin)
        sliderViewPager.addItemDecoration(MarginItemDecoration(marginPx))
        sliderViewPager2.addItemDecoration(MarginItemDecoration(marginPx))
    }
}
