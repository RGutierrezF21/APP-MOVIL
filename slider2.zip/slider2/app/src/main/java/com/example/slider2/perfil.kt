package com.example.slider2

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class perfil : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_perfil)

        val bt_casa_perfil = findViewById<ImageView>(R.id.bt_casa_perfil)
        bt_casa_perfil.setOnClickListener {
            val intent = Intent(this, inicio::class.java)
            startActivity(intent)
            finish()
        }

        val bt_compras_perfil = findViewById<ImageView>(R.id.bt_compras_perfil)
        bt_compras_perfil.setOnClickListener{
            val intent = Intent(this, compras :: class.java)
            startActivity(intent)
            finish()
        }

        val bt_usuario_perfil = findViewById<ImageView>(R.id.bt_usuario_perfil)
        bt_usuario_perfil.setOnClickListener{
            val intent = Intent(this, perfil :: class.java)
            startActivity(intent)
            finish()
        }

        val tvHistorial = findViewById<TextView>(R.id.tv_historial)
        tvHistorial.setOnClickListener {
            val intent = Intent(this, HistorialActivity::class.java)
            startActivity(intent)
        }

        val tvPedidos = findViewById<TextView>(R.id.tv_pedidos)
        tvPedidos.setOnClickListener {
            val intent = Intent(this, PedidosActivity::class.java)
            startActivity(intent)
        }

        val tvDirecciones = findViewById<TextView>(R.id.tv_direcciones)
        tvDirecciones.setOnClickListener {
            val intent = Intent(this, DireccionesActivity::class.java)
            startActivity(intent)
        }

        val tvResenas = findViewById<TextView>(R.id.tv_resenas)
        tvResenas.setOnClickListener {
            val intent = Intent(this, ResenasActivity::class.java)
            startActivity(intent)
        }



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}