package com.example.slider2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class ResenasActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resenas);

        configurarBotones();
    }

    private void configurarBotones() {
        ImageView btCasa = findViewById(R.id.bt_casa_perfil);
        ImageView btCompras = findViewById(R.id.bt_compras_perfil);
        ImageView btUsuario = findViewById(R.id.bt_usuario_perfil);

        btCasa.setOnClickListener(v -> {
            startActivity(new Intent(ResenasActivity.this, inicio.class));
            finish();
        });

        btCompras.setOnClickListener(v -> {
            startActivity(new Intent(ResenasActivity.this, compras.class));
            finish();
        });

        btUsuario.setOnClickListener(v -> {
            startActivity(new Intent(ResenasActivity.this, perfil.class));
            finish();
        });
    }
}
