package com.example.slider2

import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2

class inicio : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.inicio)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val sliderViewPager = findViewById<ViewPager2>(R.id.sliderViewPager)
        val sliderViewPager2 = findViewById<ViewPager2>(R.id.sliderViewPager2)
        val images = listOf(
            R.drawable.ropa,
            R.drawable.computadora,
            R.drawable.limpieza
        )
        val images2 = listOf(
            R.drawable.manta,
            R.drawable.lenovo,
            R.drawable.limpiezas
        )

        val ofertButton: TextView = findViewById(R.id.ofert)
        ofertButton.setOnClickListener {
            val intent = Intent(this, Ofertas::class.java)
            startActivity(intent)
        }

        val DescButton: TextView = findViewById(R.id.desc)
        DescButton.setOnClickListener {
            val intent = Intent(this, Descuentos::class.java)
            startActivity(intent)
        }


        // Adaptador del Slider
        sliderViewPager.adapter = SliderAdapter(images)
        sliderViewPager2.adapter = SliderAdapter(images2)

        // Agregar Espaciado
        val marginPx = resources.getDimensionPixelSize(R.dimen.slider_margin)
        sliderViewPager.addItemDecoration(MarginItemDecoration(marginPx))
        sliderViewPager2.addItemDecoration(MarginItemDecoration(marginPx))
    }
}
