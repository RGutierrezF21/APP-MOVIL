package com.example.slider2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.slider2.adapters.OfertaAdapter;
import com.example.slider2.models.Oferta;

import java.util.ArrayList;
import java.util.List;

public class Descuentos extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_descuentos);

        // Configurar el RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerDescuentos);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2)); // 2 columnas

        // Lista de productos con descuento
        List<Oferta> listaDescuentos = new ArrayList<>();
        listaDescuentos.add(new Oferta("Descuento en Poleras", "$30.00", R.drawable.polera));
        listaDescuentos.add(new Oferta("Smartwatch con Descuento", "$120.00", R.drawable.smartwatch));
        listaDescuentos.add(new Oferta("Zapatillas Deportivas", "$80.00", R.drawable.zapatillas));
        listaDescuentos.add(new Oferta("Tablet en Oferta", "$250.00", R.drawable.tablet));
        listaDescuentos.add(new Oferta("Teclado Mecánico", "$90.00", R.drawable.teclado));
        listaDescuentos.add(new Oferta("Cámara de Seguridad", "$110.00", R.drawable.camara));
        listaDescuentos.add(new Oferta("Monitor Full HD", "$180.00", R.drawable.monitor));
        listaDescuentos.add(new Oferta("Silla Gamer", "$220.00", R.drawable.silla_gamer));


        // Configurar el adaptador y asignarlo al RecyclerView
        OfertaAdapter adapter = new OfertaAdapter(listaDescuentos);
        recyclerView.setAdapter(adapter);
    }
}
