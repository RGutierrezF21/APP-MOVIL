package com.example.slider2.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.slider2.R
import com.example.slider2.models.Oferta

class OfertaAdapter(private val listaOfertas: List<Oferta>) :
    RecyclerView.Adapter<OfertaAdapter.OfertaViewHolder>() {

    class OfertaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imagenOferta: ImageView = itemView.findViewById(R.id.imgOferta)
        val nombreOferta: TextView = itemView.findViewById(R.id.txtNombreOferta)
        val precioOferta: TextView = itemView.findViewById(R.id.txtPrecioOferta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OfertaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_oferta, parent, false)
        return OfertaViewHolder(view)
    }

    override fun onBindViewHolder(holder: OfertaViewHolder, position: Int) {
        val oferta = listaOfertas[position]
        holder.imagenOferta.setImageResource(oferta.imagen)
        holder.nombreOferta.text = oferta.nombre
        holder.precioOferta.text = oferta.precio
    }

    override fun getItemCount(): Int = listaOfertas.size
}
