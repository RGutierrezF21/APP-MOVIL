package com.example.slider2;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.slider2.adapters.OfertaAdapter;
import com.example.slider2.models.Oferta;

import java.util.ArrayList;
import java.util.List;

public class Ofertas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ofertas);

        // Configurar el RecyclerView
        RecyclerView recyclerView = findViewById(R.id.recyclerOfertas);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        // Lista de ofertas de ejemplo
        List<Oferta> listaOfertas = new ArrayList<>();
        listaOfertas.add(new Oferta("Descuento en Zapatos", "$50.00", R.drawable.zapatos));
        listaOfertas.add(new Oferta("Laptop en Oferta", "$800.00", R.drawable.laptod));
        listaOfertas.add(new Oferta("Smartphone Rebajado", "$400.00", R.drawable.smartphone));
        listaOfertas.add(new Oferta("Reloj Inteligente", "$150.00", R.drawable.reloj));
        listaOfertas.add(new Oferta("Audífonos Bluetooth", "$70.00", R.drawable.audifonos));
        listaOfertas.add(new Oferta("Televisor 4K", "$600.00", R.drawable.televisor));
        listaOfertas.add(new Oferta("Consola de Videojuegos", "$450.00", R.drawable.consola));
        listaOfertas.add(new Oferta("Mochila Antirrobo", "$40.00", R.drawable.mochila));

        // Configurar el Adapter
        OfertaAdapter adapter = new OfertaAdapter(listaOfertas);
        recyclerView.setAdapter(adapter);
    }
}
