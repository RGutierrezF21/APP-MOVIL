package com.example.slider2.models

data class Oferta(
    val nombre: String,
    val precio: String,
    val imagen: Int
)
