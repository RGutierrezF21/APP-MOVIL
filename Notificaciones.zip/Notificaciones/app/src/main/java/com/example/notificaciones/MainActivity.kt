package com.example.notificaciones

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var bt_bell: ImageView
    private lateinit var contenedorNotificacion: LinearLayout
    private lateinit var notificationBadge: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val tiempoNotificacion: Long = 2000

    private var isNotificationShown = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bt_bell = findViewById(R.id.bt_bell)
        contenedorNotificacion = findViewById(R.id.contenedorNotificacion)
        notificationBadge = findViewById(R.id.notificationBadge)

        showNotificationBadge()

        bt_bell.setOnClickListener {
            contenedorNotificacion.visibility = View.GONE
            notificationBadge.visibility = View.GONE
        }
    }

    private fun showNotificationBadge() {
        notificationBadge.visibility = View.VISIBLE
        notificationBadge.text = "2"

        handler.postDelayed({
            notificationBadge.visibility = View.GONE
            showNotificationOnce()
        }, 5000)
    }

    private fun showNotificationOnce() {
        if (!isNotificationShown) {
            handler.postDelayed({
                contenedorNotificacion.visibility = View.VISIBLE
                isNotificationShown = true
            }, tiempoNotificacion)
        }
    }
}
